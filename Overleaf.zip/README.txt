University of Bristol Data Science MSc thesis project

Main file: main.tex
Class file: dissertation.cls
Bibliography: references.bib
Figures: images/

Upload the whole folder (or ZIP) to Overleaf and compile main.tex with pdfLaTeX.
